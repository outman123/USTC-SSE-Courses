参考链接：

https://github.com/lukas018/spark-apriori/

https://nicodechal.github.io/2018/03/07/spark-note-fpgrowth-1/