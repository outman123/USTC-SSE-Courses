package edu.ustc.nodb.DWDM.Classification.Apriori

import org.apache.spark.sql.SparkSession
import scala.collection.SortedSet

object APRMain {

    def main(args: Array[String]):Unit = {
        
        val (supThreshold, confidenceThreshold)
        = if(args.length < 2) {
            println(s"Insufficient arguments. 2 are required but received ${args.length}.")
            println(s"Setting default parameters")
            (0.01, 0.5)
        } else {
            (args(0).toDouble, args(1).toDouble)
        }
        
        val spark = SparkSession.builder().appName("Frequent Itemset")
                .config("spark.master", "local").getOrCreate()
        val sc = spark.sparkContext
        sc.setLogLevel("ERROR") // Stop outputing error

        val sourceData = Array(Array("I1","I2","I5"),
            Array("I2","I4"),
            Array("I2","I3"),
            Array("I1","I2","I4"),
            Array("I1","I3"),
            Array("I2","I3"),
            Array("I1","I3"),
            Array("I1","I2","I3","I5"),
            Array("I1","I2","I3"))
        val data = sc.parallelize(sourceData).cache()
        val baskets = data.map(x => SortedSet(x: _*))

        println("\nStart computing frequent itemsets")
        // Compute frequent itemsets and rules
        val nBaskets = baskets.count 
        val freqSets = Apriori.run[String](sc, baskets, (nBaskets*supThreshold).toInt, 10)

        freqSets.keySet.filter(_.size == 2).foreach(println)
        freqSets.keySet.filter(_.size == 3).foreach(println)
        freqSets.keySet.filter(_.size == 4).foreach(println)
        freqSets.keySet.filter(_.size == 5).foreach(println)

        val assocRules = AssocRules.generateRules[String](sc, freqSets, confidenceThreshold)
        println("Finished")        
        // Print Answers
        println(f"\nAssociations Rules with support-threshold: $supThreshold")
        assocRules.sortWith((x,y) => x.conf > y.conf).foreach(AssocRules.printRule[String])
        spark.close
    }

}