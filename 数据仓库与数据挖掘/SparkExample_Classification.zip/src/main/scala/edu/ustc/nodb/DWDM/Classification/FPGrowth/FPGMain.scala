package edu.ustc.nodb.DWDM.Classification.FPGrowth

import org.apache.log4j.{Level, Logger}
import org.apache.spark.mllib.fpm.FPGrowth
import org.apache.spark.sql.SparkSession

object FPGMain {
  Logger.getLogger("org").setLevel(Level.WARN)
  def main(args: Array[String]) {

    val spark = SparkSession.builder().master("local").appName("fp-growth").getOrCreate()
    val sc = spark.sparkContext

    val sourceData = Array(Array("I1","I2","I5"),
      Array("I2","I4"),
      Array("I2","I3"),
      Array("I1","I2","I4"),
      Array("I1","I3"),
      Array("I2","I3"),
      Array("I1","I3"),
      Array("I1","I2","I3","I5"),
      Array("I1","I2","I3"))
    val data = sc.parallelize(sourceData).cache()

    val model = new FPGrowth().setMinSupport(0.01).setNumPartitions(3).run(data)

    println(s"Number of frequent itemsets: ${model.freqItemsets.count()}")
    model.freqItemsets.collect().foreach { itemset =>

      println(itemset.items.mkString("[", ",", "]") + ":" + itemset.freq)
    }

    //antecedent -> consequent
    //filter of confidence
    model.generateAssociationRules(0.5).collect().foreach(rule => {
      println(rule.antecedent.mkString(" , ") + " --> " +
        rule.consequent.mkString(" , ") + " --> " + rule.confidence)
    })
  }
}
