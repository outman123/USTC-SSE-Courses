package edu.ustc.nodb.DWDM.Classification.FPGrowth

import org.apache.log4j.{Level, Logger}
import org.apache.spark.mllib.fpm.FPGrowth
import org.apache.spark.sql.SparkSession

object FPGMain {
  Logger.getLogger("org").setLevel(Level.WARN)
  def main(args: Array[String]) {
    // spark context
    val spark = SparkSession.builder().master("local").appName("fp-growth").getOrCreate()
    val sc = spark.sparkContext
    // Read data
    val sourceData = Array(Array("I1","I2","I5"),
      Array("I2","I4"),
      Array("I2","I3"),
      Array("I1","I2","I4"),
      Array("I1","I3"),
      Array("I2","I3"),
      Array("I1","I3"),
      Array("I1","I2","I3","I5"),
      Array("I1","I2","I3"))
    val data = sc.parallelize(sourceData).cache()
    // Use FPGrowth model
    val model = new FPGrowth().setMinSupport(0.01).setNumPartitions(3).run(data)
    // print result
    println(s"Number of frequent itemsets: ${model.freqItemsets.count()}")
    model.freqItemsets.collect().foreach { itemset =>
      // output items+support(freq)
      println(itemset.items.mkString("[", ",", "]") + ":" + itemset.freq)
    }

  }
}
