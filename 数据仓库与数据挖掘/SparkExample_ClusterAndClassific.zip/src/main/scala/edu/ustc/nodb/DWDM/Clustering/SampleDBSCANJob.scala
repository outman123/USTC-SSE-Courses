package edu.ustc.nodb.DWDM.Clustering

import org.apache.spark.mllib.clustering.dbscan.DBSCAN
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.{SparkConf, SparkContext}


// https://github.com/irvingc/dbscan-on-spark
object SampleDBSCANJob {

  def main(args: Array[String]) {

    val (src, maxPointsPerPartition, eps, minPoints) =
      ("data/DBSCANdata.txt", 12, 0.5, 4)

    val conf = new SparkConf().setAppName(s"DBSCAN(eps=$eps, min=$minPoints, max=$maxPointsPerPartition)")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer").setMaster("local[4]")
    // conf.set("spark.storage.memoryFraction", "0.1")
    val sc = new SparkContext(conf)

    val data = sc.textFile(src)

    val parsedData = data.map(s => Vectors.dense(s.split('	').map(_.toDouble))).cache()

    println(s"EPS: $eps minPoints: $minPoints")

    val model = DBSCAN.train(
      parsedData,
      eps = eps,
      minPoints = minPoints,
      maxPointsPerPartition = maxPointsPerPartition)

    val result = model.labeledPoints.map(p => s"${p.x},${p.y},${p.cluster}").collect()

    for (i <- result) {
      println(i)
    }
    println("Stopping Spark Context...")
    sc.stop()

  }
}
