package com.monitor.mapper;

import com.monitor.pojo.StaticInstance;
import tk.mybatis.mapper.common.Mapper;

interface StaticInstanceMapper extends Mapper<StaticInstance> {
}
