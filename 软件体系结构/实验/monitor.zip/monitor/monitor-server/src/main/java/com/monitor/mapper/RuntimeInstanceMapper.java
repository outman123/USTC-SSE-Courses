package com.monitor.mapper;

import com.monitor.pojo.RuntimeInstance;
import tk.mybatis.mapper.common.Mapper;

public interface RuntimeInstanceMapper extends Mapper<RuntimeInstance> {
}
