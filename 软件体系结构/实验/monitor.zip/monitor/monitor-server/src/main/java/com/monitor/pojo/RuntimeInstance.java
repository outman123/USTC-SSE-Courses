package com.monitor.pojo;

import javax.persistence.Table;

@Table(name = "runtime_instance")
public class RuntimeInstance {

  private long instanceId;
  private String ipAddr;
  private long cpuRate;
  private long networkIo;
  private long diskUsage;
  private long memoryUsage;
  private long processNumber;


  public long getInstanceId() {
    return instanceId;
  }

  public void setInstanceId(long instanceId) {
    this.instanceId = instanceId;
  }


  public String getIpAddr() {
    return ipAddr;
  }

  public void setIpAddr(String ipAddr) {
    this.ipAddr = ipAddr;
  }


  public long getCpuRate() {
    return cpuRate;
  }

  public void setCpuRate(long cpuRate) {
    this.cpuRate = cpuRate;
  }


  public long getNetworkIo() {
    return networkIo;
  }

  public void setNetworkIo(long networkIo) {
    this.networkIo = networkIo;
  }


  public long getDiskUsage() {
    return diskUsage;
  }

  public void setDiskUsage(long diskUsage) {
    this.diskUsage = diskUsage;
  }


  public long getMemoryUsage() {
    return memoryUsage;
  }

  public void setMemoryUsage(long memoryUsage) {
    this.memoryUsage = memoryUsage;
  }


  public long getProcessNumber() {
    return processNumber;
  }

  public void setProcessNumber(long processNumber) {
    this.processNumber = processNumber;
  }

}
