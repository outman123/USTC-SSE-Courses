package com.monitor.controller;

import com.monitor.pojo.RuntimeInstance;
import com.monitor.service.InstanceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@Api("实例查询接口")
public class InstanceController {
    @Autowired
    InstanceService instanceService;
    @GetMapping("runtime/{id}")
    @ApiOperation(value = "根据id查询运行时状态", notes = "查询运行时状态")
    @ApiImplicitParam(name = "id", required = true, value = "实例id")
    public ResponseEntity<RuntimeInstance> queryRuntimeInstanceById(@PathVariable("id")Long id){
        RuntimeInstance runtimeInstance = this.instanceService.queryRuntimeInstanceById(id);
        if (runtimeInstance == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(runtimeInstance);
    }
}
