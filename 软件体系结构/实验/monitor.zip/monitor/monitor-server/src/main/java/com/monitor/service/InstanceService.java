package com.monitor.service;

import com.monitor.mapper.RuntimeInstanceMapper;
import com.monitor.pojo.RuntimeInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InstanceService {
    @Autowired
    RuntimeInstanceMapper runtimeInstanceMapper;

    public RuntimeInstance queryRuntimeInstanceById(Long id){
        RuntimeInstance runtimeInstance=new RuntimeInstance();
        runtimeInstance.setInstanceId(id);
        return this.runtimeInstanceMapper.selectOne(runtimeInstance);
    }
}
