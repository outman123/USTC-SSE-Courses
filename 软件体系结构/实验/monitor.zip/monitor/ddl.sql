create schema monitor;
use monitor;
drop table static_instance;
create table static_instance(
    instance_id int not null auto_increment,
    name varchar(30),
    region varchar(20),
    status int,
    primary key (instance_id)
);
drop table runtime_instance;
create table runtime_instance(
    instance_id int,
    ip_addr varchar(20),
    cpu_rate int,
    network_io int,
    disk_usage int,
    memory_usage int,
    process_number int,
    foreign key fk_id(instance_id) references static_instance(instance_id)
);

insert into static_instance(name, region,status) values ('instance1','杭州','1');
insert into static_instance(name, region,status) values ('instance2','上海','1');

insert into runtime_instance values (1,'102.168.1.121',20,10,40,63,232);