gateway暂时还未启用<br>
只写了server的demo，演示swagger框架生成文档的方法<br>
用idea打开整个工程<br>
先运行monitor-register<br>
再运行monitor-server<br>
成功运行后，通过浏览器访问http://localhost:9092/swagger-ui.html/查看接口文档